---
name: Estate Command
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#9b4500'
  on-secondary: '#ffffff'
  secondary-container: '#fd8a42'
  on-secondary-container: '#682c00'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002117'
  on-tertiary-container: '#528f79'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb68e'
  on-secondary-fixed: '#331200'
  on-secondary-fixed-variant: '#763300'
  tertiary-fixed: '#b0f0d6'
  tertiary-fixed-dim: '#95d3ba'
  on-tertiary-fixed: '#002117'
  on-tertiary-fixed-variant: '#0b513d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Public Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Public Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  stats-number:
    fontFamily: Public Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Public Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-padding: 24px
  gutter: 16px
  touch-target: 48px
  card-gap: 20px
---

## Brand & Style
The design system is engineered for high-stakes property management, blending the technical precision of a GIS tool with the prestige of a luxury concierge service. The target audience—professional Indian property dealers—requires a UI that commands authority and facilitates quick decision-making without technical friction.

The style is **Premium SaaS**, characterized by:
- **Clarity & Authority:** Drawing inspiration from Apple Maps, using ample whitespace and a "map-first" hierarchy where data overlays feel integrated, not intrusive.
- **Glassmorphism Lite:** Using frosted surfaces for floating map panels to maintain spatial awareness of the terrain beneath the data.
- **Modern Professionalism:** A light-themed environment that feels airy yet grounded, avoiding neon trends in favor of a timeless, institutional aesthetic.

## Colors
The palette is rooted in "Power Neutrals" to ensure longevity and trust.
- **Primary (Deep Navy):** #0F172A. Used for primary navigation, headings, and high-priority actions. It provides the "Executive" feel.
- **Secondary (Sophisticated Amber):** #B45309. Reserved for "Hot" leads, urgent alerts, and premium property highlights. It is a refined gold-adjacent tone, not a bright warning yellow.
- **Success (Forest Emerald):** #064E3B. A deep, professional green used for "Closed" deals and positive growth metrics.
- **Neutral (Slate & Ice):** A range of cool grays (Slate 50 to 600) for borders and secondary text, keeping the interface feeling clean and "Map-like."

## Typography
We use **Public Sans** for its institutional clarity and excellent legibility for users in the 45-55 age bracket. 
- **Numerical Dominance:** Real estate is data-driven. We use `stats-number` for property prices and lead counts to ensure they are the first thing a user sees.
- **Hierarchy:** Headlines use semi-bold weights to contrast against the map background.
- **Tap Readiness:** Body text is slightly larger than standard SaaS (16px minimum) to accommodate tablet usage and ease of reading during field operations.

## Layout & Spacing
The layout employs a **Hybrid Fluid Grid** optimized for a map-centric experience.
- **Map Canvas:** The base layer is a full-bleed map.
- **Floating Command Panels:** Interaction panels (CRM, Lead List) float 24px from the screen edges with a "glass" backdrop.
- **Horizontal Pipeline:** The deal flow uses a horizontal scrolling container with fixed-width "Stage" columns (320px) to maintain a clear visual path from "Inquiry" to "Closed."
- **Tablet Optimization:** All interactive elements maintain a minimum 48px hit area to ensure the "Command Center" is usable on iPads during site visits.

## Elevation & Depth
Depth is used to signify "Utility over Information."
- **Level 0 (Map):** The foundation.
- **Level 1 (Panels):** Uses a subtle backdrop blur (20px) and a 60% white fill. This creates a "Glass" effect that feels modern and lightweight.
- **Level 2 (Cards):** Active data points use multi-layered ambient shadows. A sharp 1px shadow for definition combined with a soft, 15% opacity Deep Navy blur (24px) to create a "lifted" feel.
- **Outlines:** We use low-contrast Slate-200 borders on all cards to ensure they don't get lost against high-detail map imagery.

## Shapes
We use a **Rounded (0.5rem)** strategy. This avoids the "playfulness" of pill shapes while feeling more modern and premium than sharp corners. 
- **Buttons & Inputs:** Consistent 8px (0.5rem) radius.
- **Large Panels:** Use `rounded-xl` (1.5rem) to soften the large screen real estate they occupy.
- **Map Markers:** Distinctive "Pin" shapes with a slight 4px bottom radius to point precisely at land parcels.

## Components
- **Primary Buttons:** Deep Navy fill, white text, 18px padding. These represent "Commitment" actions (e.g., Generate Agreement).
- **Property Cards:** Generous 24px padding. Headline in `headline-md`, price in `stats-number`. Includes a "Map Sync" icon to highlight the location on the main view.
- **Status Chips:** High-contrast background with dark text. "Hot" leads use the Amber palette with a subtle pulse animation.
- **Input Fields:** Soft Slate-100 backgrounds that darken on focus. No heavy borders; use subtle inner shadows to indicate depth.
- **Pipeline Stages:** Sophisticated headers with a count indicator in a circle. Each stage is separated by a ghost-line to maintain the "Process" feel.
- **Map Tooltips:** Minimalist white containers with a 1px Navy border, appearing on hover/tap of a property pin.